/*******************************************************************************************
* Author: Sean Elia
* Date: 10/5/20
* File: driver.cpp
*
* The driver file for a team creation and management project
*******************************************************************************************/
#include <iostream>
#include <string>
#include <list>

int mainMenu(); // displays text and returns an integer value
std::string getMember(); // gets the name of a team member from the user
void listMembers(std::list<std::string>); // lists all current team members
int numMembers(std::list<std::string>); // counts the number of team members and returns that value
//----------------------------------------------------------------------------
// main method
//----------------------------------------------------------------------------
int main() {
	std::cout << "WELCOME TO THE TEAM MANAGER APPLICATION\n";
	std::cout << "=======================================\n";

	int choice, temp;
	std::list<std::string> team;
	do {
		choice = mainMenu();
		switch(choice) {
			case 0: break; 	// do nothing if quiting
			case 1:		// add a team member
				team.push_front(getMember());
				std::cout << "TEAM MEMBER ADDED\n\n";
			break;
			case 2:		//remove a team member
				temp = team.size();
				team.remove(getMember());
				if(temp > team.size()) {
					std::cout << "TEAM MEMBER REMOVED\n\n";
				} else {
					std::cout << "THEY ARE NOT ON THE TEAM\n\n";
				}
			break;
			case 3:		// lists the entire team
				listMembers(team);
			break;
			case 4: 	// list the number of team members
				std::cout << "THERE ARE " << numMembers(team) << " TEAM MEMBERS\n\n";
			break;
			default:	// case is undefined
				std::cerr << "INVALID INPUT, TRY AGAIN\n";
		}
	} while (choice != 0);
	return 0;
}

//------------------------------------------------------------------------------
// mainMenu() - displays some text with possible input values and then
//		returns the input value
//------------------------------------------------------------------------------
int mainMenu() {
	int input;
	std::cout << "MAIN MENU:\n";
        std::cout << "1.\tADD A TEAM MEMBER\n2.\tREMOVE A TEAM MEMBER\n";
	std::cout << "3.\tLIST TEAM MEMBERS\n4.\tCOUNT TEAM MEMBERS\n";
	std::cout << "0.\tQUIT APPLICATION\n\nWHAT DO YOU CHOOSE:  ";
	std::cin >> input;
	return input;
}


//------------------------------------------------------------------------------
// getMember() - gets the name of a team member from the user and returns it
//------------------------------------------------------------------------------
std::string getMember() {
	std::string str;
        std::cout << "ENTER TEAM MEMBER NAME: ";
        std::cin >> str;
	return str;
}


//------------------------------------------------------------------------------
// list members(list<string>) - displays all team members
//------------------------------------------------------------------------------
void listMembers(std::list<std::string> team) {
	if (team.size() == 0) {
		std::cout << "TEAM IS CURRENTLY EMPTY\n\n";
	} else{
		std::cout << "TEAM: ";
		for(std::list<std::string>::iterator it = team.begin(); it != team.end(); it++) {
			std::cout << *(it) << ", ";
		}
		std::cout << "\n\n";
	}
}


//------------------------------------------------------------------------------
// numMembers(list<string>) - returns the number of current team members
//------------------------------------------------------------------------------
int numMembers(std::list<std::string> team) {
        return team.size();
}
