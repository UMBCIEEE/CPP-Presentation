/************************************************************************************************
* Author: Sean Elia
* Date: 10/5/20
* File: liveDemo.cpp
*
* A live demo for writing simple code in C++
************************************************************************************************/
#include <iostream>
#include <string>

using namespace std;

bool testString(string);	// tests the value of a string

//----------------------------------------------------------------
// main - the main method
//----------------------------------------------------------------
int main() {
	cout << "Hello World!" << endl;

	string str;

	while (str != "exit") {
		cout << "Please type a word(\"exit\" to quit:\n>>> ";
		cin >> str;

		if (testString(str)){
			cerr << "ERROR: wrong programming language\n";
		} else {
			cout << str <<  endl;
		}

	}

	return 0;
}


//----------------------------------------------------------------
// testString(string) - tests the value of a string to determine
//			if it is either "python" or "java" in a way
//			that is not case sensitive. Returns the
//			result as a boolean.
//----------------------------------------------------------------
bool testString(string str) {
	for(int i = 0; i < str.length(); i ++) {
		str[i] = toupper(str[i]);
	}

	if (str == "PYTHON" || str == "JAVA" ) {
		return true;
	} else {
		return false;
	}
}
